-- Insertion des centres médicaux
INSERT INTO CentreMedical (Adresse, CodePostal, Ville) VALUES
  ('123 Rue de la Santé', 67200, 'Strasbourg'),
  ('456 Rue des Oliviers', 88100, 'Saint-Die-des-Vosges'),
  ('789 Rue de la Vigne', 67230, 'Benfeld'),
  ('321 Rue du Sport', 68000, 'Colmar'),
  ('Hopital de Hautepierre', 67200, 'Strasbourg');

-- Insertion des utilisateurs (patients)
INSERT INTO Utilisateur (Prenom, Nom) VALUES
  ('Alice', 'Dupont'),  -- Utilisateur 1
  ('Bob', 'Martin'),    -- Utilisateur 2
  ('Claire', 'Lemoine'), -- Utilisateur 3
  ('David', 'Durand'),  -- Utilisateur 4
  ('Eve', 'Moreau');    -- Utilisateur 5

-- Insertion des patients
INSERT INTO Patient (IdUser, Adresse_principale, CodePostal_principale, Ville_principale, Adresse_temporaire, CodePostal_temporaire, Ville_temporaire) VALUES
  (1, '12 Rue des Lilas', 75001, 'Paris', NULL, NULL, NULL),  -- Patient Alice
  (2, '34 Avenue de Lyon', 69002, 'Lyon', NULL, NULL, NULL),  -- Patient Bob
  (3, '56 Rue de la République', 13001, 'Marseille', NULL, NULL, NULL),  -- Patient Claire
  (4, '78 Rue de Rivoli', 75001, 'Paris', NULL, NULL, NULL),  -- Patient David
  (5, '90 Rue de la Liberté', 33000, 'Bordeaux', NULL, NULL, NULL);  -- Patient Eve

  -- Insertion des proches
INSERT INTO Proche (IdUser) VALUES
  (6);  -- Proche 1 (par exemple, un proche de l'un des patients)


-- Insertion des rendez-vous
INSERT INTO RDV (Horaire, Date, IdUser, IdCentreMed) VALUES
  ('10:00:00', '2024-09-20', 1, 1),  -- Rendez-vous de Alice à Strasbourg
  ('14:30:00', '2024-09-21', 2, 2),  -- Rendez-vous de Bob à Saint-Die-des-Vosges
  ('09:00:00', '2024-09-22', 3, 3),  -- Rendez-vous de Claire à Benfeld
  ('11:00:00', '2024-09-23', 4, 4),  -- Rendez-vous de David à Colmar
  ('08:30:00', '2024-09-24', 5, 5);  -- Rendez-vous de Eve à Strasbourg

-- Insertion des relations entre proches et patients
INSERT INTO Proche_Patient (IdPatient, IdProche) VALUES
  (1, 6),  -- Proche lié au patient Alice
  (2, 6);  -- Même proche lié au patient Bob
