-- Création de la base de données
CREATE DATABASE IF NOT EXISTS MedicAssist;

-- Sélectionner la base de données
USE MedicAssist;

CREATE TABLE IF NOT EXISTS CentreMedical (
  IdCentreMed INT PRIMARY KEY AUTO_INCREMENT,
  Adresse VARCHAR(255) NOT NULL,
  CodePostal INT NOT NULL, -- Code Postal
  Ville VARCHAR(255) NOT NULL
  -- Vous pouvez ajouter d'autres attributs spécifiques au centre médical
);

CREATE TABLE IF NOT EXISTS Utilisateur (
  IdUser INT PRIMARY KEY AUTO_INCREMENT,
 -- IdRainBow 
  Prenom VARCHAR(100) NOT NULL,
  Nom VARCHAR(100) NOT NULL
  
);


CREATE TABLE IF NOT EXISTS Patient (
  IdUser INT PRIMARY KEY,
  Adresse_principale VARCHAR(255) NOT NULL,
  CodePostal_principale INT NOT NULL, 
  Ville_principale VARCHAR(255) NOT NULL,
  Adresse_temporaire VARCHAR(255), -- a n'utiliser si jamais on ne part pas du lieu habituel
  CodePostal_temporaire INT ,
  Ville_temporaire VARCHAR(255) ,
  FOREIGN KEY (IdUser) REFERENCES Utilisateur(IdUser) ON DELETE CASCADE
  -- Vous pouvez ajouter d'autres attributs spécifiques aux patients
);

CREATE TABLE IF NOT EXISTS Proche (
  IdUser INT PRIMARY KEY,
  FOREIGN KEY (IdUser) REFERENCES Utilisateur(IdUser) ON DELETE CASCADE
  -- Vous pouvez ajouter d'autres attributs spécifiques aux proches
);

CREATE TABLE IF NOT EXISTS PersonnelMed (
  IdUser INT PRIMARY KEY,
  FOREIGN KEY (IdUser) REFERENCES Utilisateur(IdUser) ON DELETE CASCADE
  -- Vous pouvez ajouter d'autres attributs spécifiques au personnel médical
);


CREATE TABLE IF NOT EXISTS RDV (
  IdRDV INT PRIMARY KEY AUTO_INCREMENT,
  Horaire TIME NOT NULL,
  Date DATE NOT NULL,
  IdUser INT,
  IdCentreMed INT,
  FOREIGN KEY (IdUser) REFERENCES Utilisateur(IdUser) ON DELETE CASCADE,
  FOREIGN KEY (IdCentreMed) REFERENCES CentreMedical(IdCentreMed) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS Proche_Patient (
  IdPatient INT,
  IdProche INT,
  PRIMARY KEY (IdPatient, IdProche),
  FOREIGN KEY (IdPatient) REFERENCES Patient(IdUser) ON DELETE CASCADE,
  FOREIGN KEY (IdProche) REFERENCES Proche(IdUser) ON DELETE CASCADE
);


